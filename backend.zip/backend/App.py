from flask import Flask, request, jsonify, send_file, render_template_string,send_from_directory, Response
from flask_cors import CORS
import matplotlib
import requests
from openai import OpenAI
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from pymongo import MongoClient
import os
from transformers import GPT2Tokenizer, GPT2LMHeadModel
import torch
import matplotlib.pyplot as plt
from io import BytesIO
import numpy as np
matplotlib.use('Agg')  # Avoids Tkinter threading conflicts








app = Flask(__name__)
CORS(app)  # Enable CORS for frontend requests
MONGO_URI = "mongodb://127.0.0.1:27017"

# Establish connection
client = MongoClient(MONGO_URI)

# Select the database and collection
db = client["student_records"]  # Database name
collection = db["students"]      # Collection name
courses_collection = db["courses"]  # Courses collection
instructors_collection = db["instructors"]
report = db['report']




# upload_json
@app.route("/upload", methods=["POST"])
def upload_json():
    try:
        data = request.json  # Get JSON data from frontend
        if not data:
            return jsonify({"error": "No data received"}), 400
        
        # Ensure data is a list before inserting
        if isinstance(data, dict):
            data = [data]

        result = collection.insert_many(data)
        return jsonify({
            "message": "Data inserted successfully",
            "inserted_count": len(result.inserted_ids) if result.inserted_ids else 0
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    
# Fetch all students data
@app.route("/get_students", methods=["GET"])
def get_students():
    students = list(collection.find({}, {"_id": 0}))  # Exclude MongoDB _id field
    return jsonify(students)

# Fetch a specific student by student ID
@app.route("/get_student/<student_id>", methods=["GET"])
def get_student(student_id):
    try:
        # Query the student by student_id
        student = collection.find_one({"Student ID": student_id}, {"_id": 0})
        if student:
            return jsonify(student)
        else:
            return jsonify({"error": "Student not found"}), 404
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Clear database
@app.route('/clear_database', methods=['POST'])
def clear_database():
    data = request.json
    if data.get("action") == "clear":
        collection.delete_many({})
        return jsonify({"message": "Database cleared successfully"})
    return jsonify({"message": "No action taken"})


# CLEARS INSTA 
@app.route('/clear', methods=['POST'])
def clear():
    data = request.json
    if data.get("action") == "clear":
        instructors_collection.delete_many({})
        return jsonify({"message": "Database cleared successfully"})
    return jsonify({"message": "No action taken"})   
# clear courses
@app.route('/clear_page_data', methods=['POST'])
def clear_page_data():
    data = request.json  # Get JSON data from request
    if data.get("action") == "clear":
        courses_collection.delete_many({})  # Clear courses collection
        return jsonify({"message": "Page data cleared successfully"})
    return jsonify({"message": "No action taken"})



# upload data
@app.route("/add_student", methods=["POST"])
def add_student():
    try:
        data = request.json  # Get JSON data from frontend

        if not data:
            return jsonify({"error": "No data received"}), 400

        # Ensure all required fields are present
        required_fields = [
            "Student ID", "Course ID", "Student Name",
            "Course Name", "Semester", "Department"
        ]
        for field in required_fields:
            if field not in data or not data[field]:
                return jsonify({"error": f"Missing field: {field}"}), 400

        # Insert student details into MongoDB
        student_id = collection.insert_one(data).inserted_id

        return jsonify({"message": "Student added successfully", "id": str(student_id)}), 201

    except Exception as e:
        return jsonify({"error": str(e)}), 500
    


# add course

@app.route("/add_course", methods=["POST"])
def add_course():
    try:
        data = request.get_json()  # Ensure we are getting JSON
        if not data:
            return jsonify({"error": "No data received"}), 400

        if not isinstance(data, list):  # Expecting a list of courses
            return jsonify({"error": "Expected a list of courses"}), 400

        result = courses_collection.insert_many(data)
        return jsonify({
            "message": "Courses added successfully",
            "inserted_count": len(result.inserted_ids)
        }), 201

    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Fetch all courses
@app.route("/get_courses", methods=["GET"])
def get_courses():
    courses = list(courses_collection.find({}, {"_id": 0}))  # Exclude MongoDB _id field
    return jsonify(courses)

# Fetch a specific course by course ID
@app.route("/get_course/<course_id>", methods=["GET"])
def get_course(course_id):
    try:
        # Query the course by course_id
        course = courses_collection.find_one({"Course ID": course_id}, {"_id": 0})
        if course:
            return jsonify(course)
        else:
            return jsonify({"error": "Course not found"}), 404
    except Exception as e:
        return jsonify({"error": str(e)}), 500



# upload instructors_collection
@app.route("/add_instructor", methods=["POST"])
def add_instructor():
    try:
        data = request.get_json()  # Ensure JSON data is received
        if not data:
            return jsonify({"error": "No data received"}), 400

        if not isinstance(data, list):  # Expecting a list of instructors
            return jsonify({"error": "Expected a list of instructors"}), 400

        result = instructors_collection.insert_many(data)
        return jsonify({
            "message": "Instructors added successfully",
            "inserted_count": len(result.inserted_ids)
        }), 201

    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Fetch all instructors
@app.route("/get_instructors", methods=["GET"])
def get_instructors():
    instructors = list(instructors_collection.find({}, {"_id": 0}))  # Exclude MongoDB _id field
    return jsonify(instructors)

# Fetch a specific instructor by ID
@app.route("/get_instructor/<string:instructor_id>", methods=["GET"])
def get_instructor(instructor_id):
    try:
        # Query the instructor by instructor_id
        instructor = instructors_collection.find_one({"INSTRUCTOR ID": instructor_id}, {"_id": 0})
        if instructor:
            return jsonify(instructor)
        else:
            return jsonify({"error": "Instructor not found"}), 404
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    



    # report

@app.route('/report', methods=['POST'])
def add_report():
    try:
        data = request.json  # Expecting a single JSON object
        if not isinstance(data, dict):  # Check if it's a dictionary (single object)
            return jsonify({"error": "Data must be a JSON object"}), 400
        
        # Delete all existing documents in the report collection
        report.delete_many({})

        # Insert the new document
        inserted = report.insert_one(data)
        return jsonify({
            "message": "Data inserted successfully",
            "inserted_id": str(inserted.inserted_id)
        }), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/get_report', methods=['GET'])
def get_report():
    try:
        data = list(report.find({}, {"_id": 0}))  # Exclude _id from results
        return jsonify(data), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    
























tokenizer = GPT2Tokenizer.from_pretrained("gpt2")
model = GPT2LMHeadModel.from_pretrained("gpt2")
EXTERNAL_API_URL = "http://127.0.0.1:5000/get_report"

# client = OpenAI(api_key="your_api_key")
# def fetch_data_from_api():
#     """Fetch data from the external API."""
#     response = requests.get(EXTERNAL_API_URL)
#     if response.status_code == 200:
#         return response.json()  # Assuming the API returns JSON data
#     else:
#         raise Exception(f"Failed to fetch data from API: {response.status_code}")

# def generate_report_with_chatgpt(data):
#     """Generate a report using ChatGPT."""
#     prompt = f"Create a detailed report based on the following data:\n{data}"
#     response = client.chat.completions.create(
#         model="gpt-3.5-turbo",
#         messages=[
#             {"role": "system", "content": "You are a helpful assistant."},
#             {"role": "user", "content": prompt}
#         ]
#     )
#     return response.choices[0].message.content

# def create_pdf(report_text, filename="report.pdf"):
#     """Create a PDF from the report text."""
#     c = canvas.Canvas(filename, pagesize=letter)
#     text = c.beginText(40, 750)
#     text.setFont("Helvetica", 12)
#     for line in report_text.split('\n'):
#         text.textLine(line)
#     c.drawText(text)
#     c.save()
#     return filename

# @app.route('/generate-report', methods=['GET'])
# def generate_report():
#     try:
#         # Step 1: Fetch data from the external API
#         data = fetch_data_from_api()

#         # Step 2: Generate a report using ChatGPT
#         report_text = generate_report_with_chatgpt(data)

#         # Step 3: Create a PDF from the report
#         pdf_filename = create_pdf(report_text)

#         # Step 4: Serve the PDF to open in a new tab
#         return render_template_string('''
#             <script>
#                 window.open("{{ url_for('static', filename=pdf_filename) }}", "_blank");
#             </script>
#         ''', pdf_filename=pdf_filename)

#     except Exception as e:
#         return f"An error occurred: {str(e)}", 500
    
























def fetch_data_from_api():
    """Fetch data from the external API."""
    response = requests.get(EXTERNAL_API_URL)
    if response.status_code == 200:
        return response.json()  # Assuming the API returns JSON data
    else:
        raise Exception(f"Failed to fetch data from API: {response.status_code}")

def generate_report_with_gpt2(data):
    """Generate a report using GPT-2."""
    prompt = f"Create a detailed report based on the following data:\n{data}"
    
    # Tokenize the input prompt
    inputs = tokenizer.encode(prompt, return_tensors="pt")
    
    # Generate text using GPT-2
    outputs = model.generate(
        inputs,
        max_length=500,  # Adjust the length of the generated text
        num_return_sequences=1,  # Generate only one sequence
        no_repeat_ngram_size=2,  # Avoid repetition
        top_k=50,  # Top-k sampling
        top_p=0.95,  # Nucleus sampling
        temperature=0.7,  # Control randomness
    )
    
    # Decode the generated text
    report_text = tokenizer.decode(outputs[0], skip_special_tokens=True)
    return report_text

def create_pdf(report_text, filename="report.pdf"):
    """Create a PDF from the report text."""
    c = canvas.Canvas(filename, pagesize=letter)
    text = c.beginText(40, 750)
    text.setFont("Helvetica", 12)
    for line in report_text.split('\n'):
        text.textLine(line)
    c.drawText(text)
    c.save()
    return filename

@app.route('/generate-report', methods=['GET'])
def generate_report():
    try:
        # Step 1: Fetch data from the external API
        data = fetch_data_from_api()

        # Step 2: Generate a report using GPT-2
        report_text = generate_report_with_gpt2(data)

        # Step 3: Create a PDF from the report
        pdf_filename = create_pdf(report_text)

        # Step 4: Serve the PDF to open in a new tab
        return render_template_string('''
            <script>
                window.open("{{ url_for('static', filename=pdf_filename) }}", "_blank");
            </script>
        ''', pdf_filename=pdf_filename)

    except Exception as e:
        return f"An error occurred: {str(e)}", 500
    





GRADE_MAPPING = {
    "A": 4.0, "A-": 3.7, "B+": 3.3, "B": 3.0, "B-": 2.7, "C+": 2.3,
    "C": 2.0, "C-": 1.7, "D+": 1.3, "D": 1.0, "F": 0.0
}

STUDENT_API_URL = "http://127.0.0.1:5000/get_student"
@app.route("/scatter-plot/<student_id>")
def generate_student_scatter_plot(student_id):
    try:
        # Fetch student data from the API
        response = requests.get(f"{STUDENT_API_URL}/{student_id}")
        if response.status_code != 200:
            return jsonify({"error": "Student not found"}), 404

        student_data = response.json()
        courses = student_data.get("Courses", [])

        if not courses:
            return jsonify({"error": "No course data available"}), 400

        # Extract Attendance and Grade (converted to GPA)
        attendance = []
        grades_numeric = []

        for course in courses:
            attendance.append(course["Attendance"])
            grade = course.get("Grade", "F")
            grades_numeric.append(GRADE_MAPPING.get(grade, 0.0))

        # Create Scatter Plot
        plt.figure(figsize=(7, 5))
        plt.scatter(attendance, grades_numeric, color="blue", alpha=0.7, label="Course Data")

        # Fit a trend line (Linear Regression)
        m, b = np.polyfit(attendance, grades_numeric, 1)
        trend_line = np.array(attendance) * m + b
        plt.plot(attendance, trend_line, color="red", linestyle="dashed", label="Trend Line")

        # Plot Labels
        plt.xlabel("Attendance (%)")
        plt.ylabel("Grade (GPA Scale)")
        plt.title(f"Impact of Attendance on Grades - Student {student_id}")
        plt.legend()
        plt.grid(True)

        # Save plot to a buffer
        buffer = BytesIO()
        plt.savefig(buffer, format="png")
        plt.close()
        buffer.seek(0)

        return Response(buffer.getvalue(), mimetype="image/png")

    except Exception as e:
        return jsonify({"error": str(e)}), 500
    
if __name__ == "__main__":
    app.run(debug=True)